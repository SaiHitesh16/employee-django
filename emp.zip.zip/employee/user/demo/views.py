from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def emp(response,name,age,salary):
	return HttpResponse("Employee details : {} age:{} Ssalary: {}".format(name,age,salary))